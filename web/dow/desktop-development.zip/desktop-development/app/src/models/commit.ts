import { CommitIdentity } from './commit-identity'
import { ITrailer, isCoAuthoredByTrailer } from '../lib/git/interpret-trailers'
import { GitAuthor } from './git-author'

/** Shortens a given SHA. */
export function shortenSHA(sha: string) {
  return sha.slice(0, 9)
}

/** Grouping of information required to create a commit */
export interface ICommitContext {
  /**
   * The summary of the commit message (required)
   */
  readonly summary: string
  /**
   * Additional details for the commit message (optional)
   */
  readonly description: string | null
  /**
   * Whether or not it should amend the last commit (optional, default: false)
   */
  readonly amend?: boolean
  /**
   * An optional array of commit trailers (for example Co-Authored-By trailers) which will be appended to the commit message in accordance with the Git trailer configuration.
   */
  readonly trailers?: ReadonlyArray<ITrailer>
}

/**
 * Extract any Co-Authored-By trailers from an array of arbitrary
 * trailers.
 */
function extractCoAuthors(trailers: ReadonlyArray<ITrailer>) {
  const coAuthors = []

  for (const trailer of trailers) {
    if (isCoAuthoredByTrailer(trailer)) {
      const author = GitAuthor.parse(trailer.value)
      if (author) {
        coAuthors.push(author)
      }
    }
  }

  return coAuthors
}

function trimCoAuthorsTrailers(
  trailers: ReadonlyArray<ITrailer>,
  body: string
) {
  let trimmedCoAuthors = body

  trailers.filter(isCoAuthoredByTrailer).forEach(({ token, value }) => {
    trimmedCoAuthors = trimmedCoAuthors.replace(`${token}: ${value}`, '')
  })

  return trimmedCoAuthors
}

/**
 * A minimal shape of data to represent a commit, for situations where the
 * application does not require the full commit metadata.
 *
 * Equivalent to the output where Git command support the
 * `--oneline --no-abbrev-commit` arguments to format a commit.
 */
export type CommitOneLine = {
  /** The full commit id associated with the commit */
  readonly sha: string
  /** The first line of the commit message */
  readonly summary: string
}

/** A git commit. */
export class Commit {
  /**
   * A list of co-authors parsed from the commit message
   * trailers.
   */
  public readonly coAuthors: ReadonlyArray<GitAuthor>

  /**
   * The commit body after removing coauthors
   */
  public readonly bodyNoCoAuthors: string

  /**
   * A value indicating whether the author and the committer
   * are the same person.
   */
  public readonly authoredByCommitter: boolean

  /**
   * Whether or not the commit is a merge commit (i.e. has at least 2 parents)
   */
  public readonly isMergeCommit: boolean

  /**
   * @param sha The commit's SHA.
   * @param shortSha The commit's shortSHA.
   * @param summary The first line of the commit message.
   * @param body The commit message without the first line and CR.
   * @param author Information about the author of this commit.
   *               Includes name, email and date.
   * @param committer Information about the committer of this commit.
   *                  Includes name, email and date.
   * @param parentSHAS The SHAs for the parents of the commit.
   * @param trailers Parsed, unfolded trailers from the commit message body,
   *                 if any, as interpreted by `git interpret-trailers`
   * @param tags Tags associated with this commit.
   */
  public constructor(
    public readonly sha: string,
    public readonly shortSha: string,
    public readonly summary: string,
    public readonly body: string,
    public readonly author: CommitIdentity,
    public readonly committer: CommitIdentity,
    public readonly parentSHAs: ReadonlyArray<string>,
    public readonly trailers: ReadonlyArray<ITrailer>,
    public readonly tags: ReadonlyArray<string>
  ) {
    this.coAuthors = extractCoAuthors(trailers)

    this.authoredByCommitter =
      this.author.name === this.committer.name &&
      this.author.email === this.committer.email

    this.bodyNoCoAuthors = trimCoAuthorsTrailers(trailers, body)

    this.isMergeCommit = parentSHAs.length > 1
  }
}
